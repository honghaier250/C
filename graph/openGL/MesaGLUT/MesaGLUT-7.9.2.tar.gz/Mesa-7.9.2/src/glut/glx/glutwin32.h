#ifndef __glutwin32_h__
#define __glutwin32_h__

/* Copyright (c) Nate Robins, 1997. */

/* This program is freely distributable without licensing fees 
   and is provided without guarantee or warrantee expressed or 
   implied. This program is -not- in the public domain. */

#include "win32_x11.h"
#include "win32_glx.h"

/* We have to undef some things because Microsoft likes to pollute the
   global namespace. */
#undef TRANSPARENT

/* Win32 "equivalent" cursors - eventually, the X glyphs should be
   converted to Win32 cursors -- then they will look the same */
#define XC_arrow               IDC_ARROW
#define XC_top_left_arrow      IDC_ARROW
#define XC_hand1               IDC_SIZEALL
#define XC_pirate              IDC_NO
#define XC_question_arrow      IDC_HELP
#define XC_exchange            IDC_NO
#define XC_spraycan            IDC_SIZEALL
#define XC_watch               IDC_WAIT
#define XC_xterm               IDC_IBEAM
#define XC_crosshair           IDC_CROSS
#define XC_sb_v_double_arrow   IDC_SIZENS
#define XC_sb_h_double_arrow   IDC_SIZEWE
#define XC_top_side            IDC_UPARROW
#define XC_bottom_side         IDC_SIZENS
#define XC_left_side           IDC_SIZEWE
#define XC_right_side          IDC_SIZEWE
#define XC_top_left_corner     IDC_SIZENWSE
#define XC_top_right_corner    IDC_SIZENESW
#define XC_bottom_right_corner IDC_SIZENWSE
#define XC_bottom_left_corner  IDC_SIZENESW

#define XA_STRING 0

/* Private routines from win32_util.c */
#ifndef __CYGWIN32__
struct timeval;
extern int gettimeofday(struct timeval* tp, void* tzp);
#endif
extern void *__glutFont(void *font);
extern int __glutGetTransparentPixel(Display *dpy, XVisualInfo *vinfo);
extern void __glutAdjustCoords(Window parent, int *x, int *y, int *width, int *height);


/* Cygwin B20.1 misses the following definitions */
#ifdef __CYGWIN32__

/* from winuser.h */
#define CDS_FULLSCREEN 4

/* from mmsystem.h */
#define WINMMAPI __declspec(dllimport)
typedef UINT MMRESULT;

#define MM_JOY1MOVE 0x3A0
#define MM_JOY1ZMOVE 0x3A2
#define MM_JOY1BUTTONDOWN 0x3B5
#define MM_JOY1BUTTONUP 0x3B7

#define JOYERR_NOERROR 0
#define JOYERR_PARMS 165

#define JOY_RETURNALL 0x000000ffl

#define JOYSTICKID1 0

typedef struct joyinfoex_tag {
    DWORD dwSize;                /* size of structure */
    DWORD dwFlags;               /* flags to indicate what to return */
    DWORD dwXpos;                /* x position */
    DWORD dwYpos;                /* y position */
    DWORD dwZpos;                /* z position */
    DWORD dwRpos;                /* rudder/4th axis position */
    DWORD dwUpos;                /* 5th axis position */
    DWORD dwVpos;                /* 6th axis position */
    DWORD dwButtons;             /* button states */
    DWORD dwButtonNumber;        /* current button number pressed */
    DWORD dwPOV;                 /* point of view state */
    DWORD dwReserved1;           /* reserved for communication between winmm & driver */
    DWORD dwReserved2;           /* reserved for future expansion */
} JOYINFOEX, *PJOYINFOEX, /* NEAR */ *NPJOYINFOEX, /* FAR */ *LPJOYINFOEX;

WINMMAPI MMRESULT WINAPI joyGetPosEx( UINT uJoyID, LPJOYINFOEX pji);
WINMMAPI MMRESULT WINAPI joyReleaseCapture( UINT uJoyID);
WINMMAPI MMRESULT WINAPI joySetCapture( HWND hwnd, UINT uJoyID, UINT uPeriod, BOOL fChanged);
WINMMAPI MMRESULT WINAPI joySetThreshold( UINT uJoyID, UINT uThreshold);

#endif

#endif /* __glutwin32_h__ */
