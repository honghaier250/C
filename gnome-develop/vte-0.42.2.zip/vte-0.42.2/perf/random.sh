#!/bin/sh
dd if=/dev/urandom bs=512 count=40960
reset
