#include <glib.h>
#include <gmodule.h>
#include <glib-object.h>
#include <gio/gio.h>

int main()
{
    return 0;
}
