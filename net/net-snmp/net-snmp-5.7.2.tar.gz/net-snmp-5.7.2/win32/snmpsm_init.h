init_usm ();
