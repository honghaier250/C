shutdown_usm ();
