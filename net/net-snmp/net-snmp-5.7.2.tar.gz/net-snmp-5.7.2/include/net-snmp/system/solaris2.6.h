#include "solaris.h"
#undef NETSNMP_DONT_USE_NLIST
