
/* freebsd8 is a superset of freebsd7 */
#include "freebsd7.h"
#define freebsd7 freebsd7
