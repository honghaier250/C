
config_require (notification / snmpNotifyTable)
config_require (snmp - notification - mib / snmpNotifyFilterTable)
config_require (notification / snmpNotifyFilterProfileTable)
