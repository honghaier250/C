config_require (sctp - mib / sctpScalars) config_require (sctp - mib / sctpTables) config_add_mib (SCTP - MIB)
