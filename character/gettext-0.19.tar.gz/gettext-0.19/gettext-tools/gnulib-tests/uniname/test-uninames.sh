#!/bin/sh
exec ./test-uninames${EXEEXT} "$srcdir/uniname/UnicodeDataNames.txt"
