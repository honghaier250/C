#include "test-moo-aroot.h"

#include <stdio.h>

/* Define a subclass.  */
struct asub1 : struct aroot
{
  FILE *fp;
methods:
};
